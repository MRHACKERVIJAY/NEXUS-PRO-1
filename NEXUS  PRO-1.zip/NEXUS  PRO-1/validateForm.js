function validateForm() {
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
  
    // Email validation
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      alert("Please enter a valid email address.");
      return false;
    }
  
    // Password validation
    var passwordRegex = /^(?=.*[A-Z])(?=.*[!@#$%^&*])(?=.*[0-9]).{8,}$/;
    if (!passwordRegex.test(password)) {
      alert("Password must have at least one capital letter, one symbol, one numeric character, and be at least 8 characters long.");
      return false;
    }
  
    // If both validations pass
    return true;
  }



